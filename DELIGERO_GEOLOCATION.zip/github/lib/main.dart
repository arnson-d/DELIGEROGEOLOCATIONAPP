import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Location App',
      home: const LocationPage(),
    );
  }
}

class LocationPage extends StatefulWidget {
  const LocationPage({super.key});

  @override
  State<LocationPage> createState() => _LocationPageState();
}

class _LocationPageState extends State<LocationPage> {

  String latitude = "Loading...";
  String longitude = "Loading...";

  @override
  void initState() {
    super.initState();
    getLocation();
  }

  // =========================
  // GET LOCATION
  // =========================
  Future<void> getLocation() async {

    bool serviceEnabled;
    LocationPermission permission;

    // CHECK GPS
    serviceEnabled =
    await Geolocator.isLocationServiceEnabled();

    if (!serviceEnabled) {
      setState(() {
        latitude = "GPS OFF";
        longitude = "Turn on location";
      });
      return;
    }

    // CHECK PERMISSION
    permission =
    await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {

      permission =
      await Geolocator.requestPermission();

      if (permission ==
          LocationPermission.denied) {

        setState(() {
          latitude = "Permission Denied";
          longitude = "";
        });

        return;
      }
    }

    // DENIED FOREVER
    if (permission ==
        LocationPermission.deniedForever) {

      setState(() {
        latitude = "Permission Permanently Denied";
        longitude = "";
      });

      return;
    }

    // GET POSITION
    Position position =
    await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    setState(() {
      latitude =
          position.latitude.toString();

      longitude =
          position.longitude.toString();
    });
  }

  // =========================
  // UI
  // =========================
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: const Text("Location Display App"),
        backgroundColor: Colors.blue,
      ),

      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),

          child: Column(
            mainAxisAlignment:
            MainAxisAlignment.center,

            children: [

              const Icon(
                Icons.location_on,
                size: 80,
                color: Colors.red,
              ),

              const SizedBox(height: 20),

              Text(
                "Latitude:",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Text(
                latitude,
                style: const TextStyle(
                  fontSize: 20,
                ),
              ),

              const SizedBox(height: 20),

              Text(
                "Longitude:",
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Text(
                longitude,
                style: const TextStyle(
                  fontSize: 20,
                ),
              ),

              const SizedBox(height: 30),

              ElevatedButton(
                onPressed: getLocation,

                child: const Text(
                  "Refresh Location",
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}